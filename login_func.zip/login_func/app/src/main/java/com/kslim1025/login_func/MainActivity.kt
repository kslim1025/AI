package com.kslim1025.login_func

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputId = findViewById<TextView>(R.id.inputId)
        val inputPwd = findViewById<TextView>(R.id.inputPwd)
        val signIn = findViewById<Button>(R.id.signIn)
        val signUp = findViewById<Button>(R.id.signUp)

        inputId.setOnClickListener(){
            Toast.makeText(this,"아이디를 입력하세요",Toast.LENGTH_SHORT).show();
            Log.d("아이디입력창","아이디입력창 눌림");
        }

        inputPwd.setOnClickListener(){
            Toast.makeText(this, "비밀번호를 입력하세요",Toast.LENGTH_LONG).show();
            Log.d("비밀번호 입력창","비밀번호 입력창 눌림");
        }

        signIn.setOnClickListener(){
            if(inputId!=null) {
                Toast.makeText(this, " 로그인 합니다.", Toast.LENGTH_SHORT).show();
                Log.d("로그인 입력창","로그인 입력창 눌림");
            }else{
                Toast.makeText(this, "공백 없이 입력해주세요", Toast.LENGTH_SHORT).show();
                Log.d("로그인 입력창","로그인 입력창 눌림");
            }

        }

        signUp.setOnClickListener(){
            Toast.makeText(this,"회원가입 페이지로 넘어갑니다",Toast.LENGTH_SHORT).show();
            Log.d("회원가입 입력창","회원가입 입력창 눌림");
        }
    }

}
